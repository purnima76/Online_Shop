module.exports = (sequelize, Sequelize) => {
    const Subcategory = sequelize.define("subcategory", {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      category_id: {
        type: Sequelize.INTEGER
      },
      subcategory_name:{
          type:Sequelize.STRING
      }
      
      
    });
    return Subcategory;
  };