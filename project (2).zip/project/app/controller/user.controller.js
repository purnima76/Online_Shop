const db = require("../models");
const config = require("../config/auth.config");
const User = db.user;
var bcrypt = require("bcryptjs");
const Op = db.Sequelize.Op;

const { user } = require("../models");
const { where } = require("sequelize/dist");
var jwt = require("jsonwebtoken");

exports.signup = (req,res) =>{
    User.findOne({where:{
        email:req.body.email
    }}).then(user=>{
        if(!user){
            User.create({
                name:req.body.name,
                email:req.body.email,
                password:req.body.password,
                mobile:req.body.mobile
        
            }).then(data=>{
                var token = jwt.sign({ id: data.id },config.secret, {
                    expiresIn: 86400 // 24 hours
                  });
                  User.update({token:token},{where:{id:data.id}}).then(data=>{
        
                  },err=>{
        
                  })
        
                res.status(200).send({
                    response:true,
                    message:"User Created Successfully",
                    data:data
                })
            },err=>{
                res.status(500).send({
                    response:false,
                    message:"Something went wrong",
        
                })
            })
        }else{
            res.status(500).send({
                response:false,
                message:"email already exist",
            })
        }

    },err=>{
        res.status(500).send({
            response:false,
            message:err.message
        })
    })


};



exports.login= (req,res)=>{
    User.findOne({
        where:{
            email:req.body.email,
            password:req.body.password,
        }
    }).then(data=>{
        if(data){
        res.status(200).send({
            response:true,
            message:"login done successfully",
            data:data

        })
    }else{
        res.status(200).send({
            response:true,
            message:"email and password not match",

        })
    }
    },err=>{
        res.status(400).send({
            response:false,
            message:"something went wrong",

        })

    })
}