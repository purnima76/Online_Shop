const db = require("../models");
const config = require("../config/auth.config");
const Category = db.category;
var bcrypt = require("bcryptjs");
const Op = db.Sequelize.Op;

const { category } = require("../models");
const { where } = require("sequelize/dist");
var jwt = require("jsonwebtoken");

exports.getCategory=(req,res)=>{
    Category.findAll().then(data=>{
        res.status(200).send({
            response:true,
            message:"data fetch",
            data:data
        })
    },err=>{
        res.status(400).send({
            response:false,
            message:"data not fetch",
         
        })
    })
};