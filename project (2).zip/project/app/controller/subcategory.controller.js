const db = require("../models");
const config = require("../config/auth.config");
const Subcategory = db.subcategory;
const Category = db.category;
var bcrypt = require("bcryptjs");
const Op = db.Sequelize.Op;

const { subcategory } = require("../models");
const { where } = require("sequelize/dist");
var jwt = require("jsonwebtoken");


Category.hasMany(Subcategory, {foreignKey: 'category_id'})
Subcategory.belongsTo(Category, {foreignKey: 'category_id'})

exports.getSubCategory=(req,res)=>{
    Subcategory.findAll().then(data=>{
        res.status(200).send({
            response:true,
            message:"data fetch",
            data:data
        })
    },err=>{
        res.status(400).send({
            response:false,
            message:"data not fetch",
         
        })
    })
};

exports.getSubCategoryWithId=(req,res)=>{
  

    Subcategory.findOne({where:{
        category_id:req.body.cat_id
    }}).then(data=>{
        if(data){
        res.status(200).send({
            response:true,
            message:"data fetch",
            data:data
        })
       }else{
        res.status(400).send({
            response:false,
            message:"data not fetch",
           
        })
       }
    },err=>{
        res.status(400).send({
            response:false,
            message:"data not fetch",
        })
    })
}


exports.joinsubcategory=(req,res)=>{
    Subcategory.findAll({
        include: [{
            model: Category,
            required: true
           }]
    }).then(data=>{
        
        res.status(200).send({
            response:true,
            message:"data fetch",
            data:data
        })
    },err=>{
        res.status(400).send({
            response:false,
            message:"data not fetch",
        })
    })
};


exports.getuploadimg=(req,res)=>{
    console.log(req.file)
    // var response = '<a href="/">Home</a><br>'
    // response += "Files uploaded successfully.<br>"
    // response += `<img src="${req.file.path}" /><br>`
    // return res.send(response)
   
}