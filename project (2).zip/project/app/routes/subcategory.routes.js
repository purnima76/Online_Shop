const { authJwt } = require("../middleware");
const controller = require("../controller/subcategory.controller");
var multer  = require("multer");
var express = require('express');
const app = express();
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './uploads')
    },
    filename: function (req, file, cb) {
      cb(null, file.originalname)
    }
})
var upload = multer({ storage: storage });
app.use(express.static(__dirname + '/public'));
app.use('/uploads', express.static('uploads'));

module.exports = function(app) {
    app.use(function(req, res, next) {
      res.header(
        "Access-Control-Allow-Headers",
        "Content-Type"
      );
     res.header("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, PUT, OPTIONS");
      next();
    });
    
  
      app.get("/api/subcategory",[authJwt.verifyToken],controller.getSubCategory);
      app.post("/api/getsubcategorywithid",[authJwt.verifyToken],controller.getSubCategoryWithId);
      app.get('/api/joinsubcategory',[authJwt.verifyToken],controller.joinsubcategory);
      app.post('/api/uploadimg',upload.single('profile-file'),controller.getuploadimg);

    };