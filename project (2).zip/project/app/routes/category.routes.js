const { authJwt } = require("../middleware");
const controller = require("../controller/category.controller");

module.exports = function(app) {
    app.use(function(req, res, next) {
      res.header(
        "Access-Control-Allow-Headers",
        "Content-Type"
      );
     res.header("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, PUT, OPTIONS");
      next();
    });
    
  
      app.get("/api/category",[authJwt.verifyToken],controller.getCategory);
     

    };