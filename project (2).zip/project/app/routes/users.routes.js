const { authJwt } = require("../middleware");
const controller = require("../controller/user.controller");

module.exports = function(app) {
    app.use(function(req, res, next) {
      res.header(
        "Access-Control-Allow-Headers",
        "Content-Type"
      );
     res.header("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, PUT, OPTIONS");
      next();
    });
    
  
      app.post("/api/createuser", controller.signup);
      app.post("/api/login", controller.login);

    };