const user = require('./users.routes');
const category = require('./category.routes');
const subcategory = require('./subcategory.routes');


module.exports = (app) =>{
    user(app),
    category(app),
    subcategory(app)
    

}