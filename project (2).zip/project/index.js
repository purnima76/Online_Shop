const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const app = express();
var jwt = require("jsonwebtoken");
var multer  = require("multer");

const server = require('http').createServer(app);

const PORT = process.env.PORT || 3154;
// const PORT = process.env.PORT || 8080;
// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}.`);
// });
app.use('/images', express.static('images'))
const db = require("./app/models");
// app.use(bodyParser.json());
app.get("/", (req, res) => {
    res.json({ message: "Welcome to application." });
  });
require('./app/routes')(app);



server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});